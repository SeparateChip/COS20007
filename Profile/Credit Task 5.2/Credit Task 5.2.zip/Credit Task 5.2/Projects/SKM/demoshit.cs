using System;
using SplashKitSDK;

namespace SKM
{
    public class Program
    {
        public static void Main()
        {
            new Window("testwindow", 800, 600);
            SplashKit.Delay(5000);
        }
    }
}
