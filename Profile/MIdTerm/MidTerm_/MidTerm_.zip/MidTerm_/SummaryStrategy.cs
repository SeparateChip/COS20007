﻿using System;
using System.Collections.Generic;



namespace MidTerm_
{

    public abstract class SummaryStrategy
    {

        public abstract void PrintSummary(List<int> numbers); 


    }






}
